package com.lb.dao;

public interface TestDao {

}
